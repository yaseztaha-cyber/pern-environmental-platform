import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLenis } from "./hooks/useLenis";
import { CustomCursor } from "./components/ui/CustomCursor";
import { Nav } from "./components/ui/Nav";
import { Hero } from "./components/sections/Hero";
import { Problem } from "./components/sections/Problem";
import { Architecture } from "./components/sections/Architecture";
import { Sensors } from "./components/sections/Sensors";
import { AI } from "./components/sections/AI";
import { Dashboard } from "./components/sections/Dashboard";
import { ERI } from "./components/sections/ERI";
import { GlobalData } from "./components/sections/GlobalData";
import { Hardware } from "./components/sections/Hardware";
import { Proof } from "./components/sections/Proof";
import { Security } from "./components/sections/Security";
import { Team } from "./components/sections/Team";
import { CTAFooter } from "./components/sections/CTAFooter";

export default function App() {
  useLenis();
  const [booting, setBooting] = useState(true);

  useEffect(() => {
    const t = window.setTimeout(() => setBooting(false), 350);
    return () => window.clearTimeout(t);
  }, []);

  return (
    <div className="noise-overlay relative min-h-screen bg-[radial-gradient(ellipse_at_top,#0B1120_0%,#020617_100%)] text-[#F8FAFC]">
      <CustomCursor />

      <AnimatePresence>
        {booting && (
          <motion.div
            className="fixed inset-0 z-[100] bg-black"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          />
        )}
      </AnimatePresence>

      <Nav />
      <main>
        <Hero />
        <Problem />
        <Architecture />
        <Sensors />
        <AI />
        <Dashboard />
        <ERI />
        <GlobalData />
        <Hardware />
        <Proof />
        <Security />
        <Team />
        <CTAFooter />
      </main>
    </div>
  );
}
