export const liveStats = [
  { label: "Page Views", value: 50 },
  { label: "Sensor Types", value: 14 },
  { label: "Virtual Sensors", value: 10 },
  { label: "Automated Tests", value: 260 },
  { label: "Active Protocols", value: 5 },
] as const;

export const problemLabels = [
  "8M deaths annually from air pollution",
  "Cairo: PM2.5 exceeds WHO limits by 10x",
  "$47B annual cost to Egypt",
  "1 in 4 heart-related deaths linked to air quality",
] as const;

export const architectureLayers = [
  {
    id: "iot",
    title: "IoT Devices",
    description:
      "ESP32, NodeMCU, Gateways, and Simulators streaming multi-parameter environmental telemetry from the field.",
    items: ["ESP32", "NodeMCU", "Gateways", "Simulators"],
    accent: "#00D4AA",
  },
  {
    id: "gateway",
    title: "Protocol Gateway",
    description:
      "Unified ingress for MQTT, HTTP REST, WebSocket, CoAP, and LoRaWAN with live protocol health.",
    items: ["MQTT", "HTTP REST", "WebSocket", "CoAP", "LoRaWAN"],
    accent: "#0EA5E9",
  },
  {
    id: "backend",
    title: "Backend Platform",
    description:
      "Express API, AI Router, Automation engine, Alert Engine, and Auth/RBAC orchestrating the intelligence layer.",
    items: ["Express API", "AI Router", "Automation", "Alert Engine", "Auth/RBAC"],
    accent: "#A78BFA",
  },
  {
    id: "data",
    title: "Data & Services",
    description:
      "PostgreSQL 15, WebSocket 8081, ntfy/SMTP/SMS, and OpenRouter LLM for durable storage and outreach.",
    items: ["PostgreSQL 15", "WebSocket 8081", "ntfy/SMTP/SMS", "OpenRouter LLM"],
    accent: "#F59E0B",
  },
  {
    id: "dashboard",
    title: "React Dashboard",
    description:
      "Immersive operator console with live maps, ERI gauges, forecasts, and natural-language AI copilots.",
    items: ["Live Maps", "ERI Gauges", "Forecasts", "AI Copilot"],
    accent: "#22D3EE",
  },
] as const;

export type PhysicalSensor = {
  name: string;
  unit: string;
  range: string;
  category: "water" | "air" | "soil" | "light";
};

export const physicalSensors: PhysicalSensor[] = [
  { name: "pH", unit: "—", range: "6.5–8.5", category: "water" },
  { name: "TDS", unit: "ppm", range: "0–500", category: "water" },
  { name: "Water Temperature", unit: "°C", range: "10–30", category: "water" },
  { name: "Dissolved Oxygen", unit: "mg/L", range: "5–14", category: "water" },
  { name: "Turbidity", unit: "NTU", range: "0–5", category: "water" },
  { name: "PM2.5", unit: "µg/m³", range: "0–35", category: "air" },
  { name: "MQ135 Gas", unit: "ppm", range: "0–1.0", category: "air" },
  { name: "Air Temperature", unit: "°C", range: "15–35", category: "air" },
  { name: "Humidity", unit: "%", range: "30–70", category: "air" },
  { name: "CO₂", unit: "ppm", range: "300–1000", category: "air" },
  { name: "NH₃", unit: "ppm", range: "0–25", category: "air" },
  { name: "VOC", unit: "ppb", range: "0–500", category: "air" },
  { name: "Soil Moisture", unit: "%", range: "20–60", category: "soil" },
  { name: "Light Intensity", unit: "lux", range: "0–100000", category: "light" },
];

export const virtualSensors = [
  { name: "AQI", tier: 1, value: 72 },
  { name: "WQI", tier: 1, value: 84 },
  { name: "EHI", tier: 2, value: 61 },
  { name: "Risk Score", tier: 1, value: 38 },
  { name: "Indoor Air Quality", tier: 2, value: 78 },
  { name: "Corrosion Index", tier: 3, value: 44 },
  { name: "BOD Estimate", tier: 3, value: 55 },
  { name: "Thermal Comfort", tier: 2, value: 81 },
  { name: "Agricultural Suitability", tier: 2, value: 69 },
  { name: "Human Exposure", tier: 4, value: 47 },
] as const;

export const aiFeatures = [
  {
    title: "Chatbot",
    description: "Natural-language Q&A with SSE streaming answers",
  },
  {
    title: "Predictions",
    description: "Time-series forecasting with confidence intervals",
  },
  {
    title: "Root Cause Analysis",
    description: "AI-driven anomaly investigation",
  },
  {
    title: "Rule Generator",
    description: "Describe automation rules in plain English",
  },
  {
    title: "Knowledge Base",
    description: "Searchable environmental monitoring standards",
  },
] as const;

export const chatDemo = [
  {
    role: "user" as const,
    text: "Why did PM2.5 spike near Tanta last night?",
  },
  {
    role: "ai" as const,
    text: "A 22-hour lead forecast detected industrial plume advection. Humidity dropped 18% while MQ135 rose 0.34 ppm — consistent with nighttime stack emissions east of the canal corridor.",
  },
  {
    role: "user" as const,
    text: "Create an alert if ERI exceeds Warning for 45 minutes.",
  },
  {
    role: "ai" as const,
    text: "Rule drafted: IF eri_level IN (Warning, Critical) FOR 45m THEN notify managers via ntfy + SMS. Shall I deploy it to the Automation engine?",
  },
] as const;

export const hardwareComponents = [
  { component: "ESP32 Dev Board", cost: "350 EGP" },
  { component: "PMS5003 (PM2.5)", cost: "2,500 EGP" },
  { component: "MQ135 Gas Sensor", cost: "200 EGP" },
  { component: "DHT22 Temp/Humidity", cost: "150 EGP" },
  { component: "TDS Sensor", cost: "300 EGP" },
  { component: "pH Sensor", cost: "800 EGP" },
  { component: "Enclosure + Power", cost: "600 EGP" },
  { component: "Cloud Backend (3mo)", cost: "100 EGP" },
] as const;

export type Competitor = {
  name: string;
  price: string;
  notes: string[];
  highlight?: boolean;
};

export const competitors: Competitor[] = [
  {
    name: "AirVisual Pro",
    price: "~16,500 EGP",
    notes: ["Air only", "No prediction"],
  },
  {
    name: "PurpleAir PA-II",
    price: "~15,000 EGP",
    notes: ["No water", "No forecasting"],
  },
  {
    name: "Aeroqual Series 500",
    price: ">40,000 EGP",
    notes: ["No ML", "Infrastructure-heavy"],
  },
  {
    name: "PERN",
    price: "5,000–8,000 EGP",
    notes: ["Air + Water + Soil", "24h Forecast", "AI Copilot"],
    highlight: true,
  },
];

export const deployments = [
  {
    title: "Urban Industrial",
    location: "Tanta District",
    stats: [
      "30-day deployment",
      "99.3% Uptime",
      "12 Warning days | 5 Critical days",
      "Self-calibration flagged pH drift on Day 18 and corrected it",
      "Predicted PM2.5 spike (38→87 µg/m³) 22 hours in advance",
    ],
  },
  {
    title: "Rural Agricultural",
    location: "Nile Delta Farms",
    stats: [
      "30-day deployment",
      "97% Expert agreement",
      "3 Warning days | 0 Critical days",
      "Stable readings with low MAE",
      "Validated against WHO AQG thresholds",
    ],
  },
] as const;

export const securityFeatures = [
  { title: "Logto OIDC", description: "JWT verification" },
  { title: "RBAC", description: "Admin, Manager, Member, Viewer" },
  { title: "Helmet Hardening", description: "CSP, HSTS, X-Frame-Options" },
  { title: "Rate Limiting", description: "Sliding window per IP" },
  { title: "Parameterized SQL", description: "Zero injection surface" },
  { title: "WebSocket JWT", description: "Secure real-time upgrades" },
  { title: "Audit Logging", description: "Full administrative traceability" },
] as const;

export const team = {
  supervisor: "Manal AbdelFattah Khalil Ramia",
  members: [
    "Ahmed Mohamed Mahmoud Ali",
    "Mohamed Nour Eldeen Nazeer Elshazly",
    "Yassen Taha Hussainy Elnasher",
    "Eyad Sherrif Abdallah El Bagory",
  ],
  owner: "Yassen Taha Hussainy Elnasher",
} as const;

export const externalSources = [
  "OpenAQ",
  "WAQI",
  "Sensor.Community",
  "NASA FIRMS",
  "Sentinel-5P CAMS (OpenMeteo)",
] as const;

export const complianceFrameworks = [
  "WHO AQG 2021",
  "EPA NAAQS/AQI",
  "NSF WQI",
  "FAO-56 Penman-Monteith",
  "ASHRAE 62.1",
  "ISO 7243",
] as const;

export const eriValidation = [
  "94% expert agreement — Urban Industrial",
  "97% expert agreement — Rural Agricultural",
  "MAE: 3.1 µg/m³ on 24h PM2.5 forecast",
] as const;

export const sensorNodes = [
  { name: "Tanta", lat: 0.45, lon: -0.2 },
  { name: "Cairo", lat: 0.1, lon: 0.15 },
  { name: "Alexandria", lat: 0.55, lon: -0.55 },
  { name: "Delta Rural", lat: 0.35, lon: 0.4 },
] as const;

export function sparklineData(seed: number, points = 12): number[] {
  const data: number[] = [];
  let v = 40 + (seed % 30);
  for (let i = 0; i < points; i++) {
    v += Math.sin(i * 0.8 + seed) * 8 + ((seed * (i + 3)) % 7) - 3;
    data.push(Math.max(5, Math.min(100, v)));
  }
  return data;
}
