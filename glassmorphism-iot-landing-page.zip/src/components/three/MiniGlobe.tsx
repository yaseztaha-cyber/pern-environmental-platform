import { memo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Sphere } from "@react-three/drei";
import * as THREE from "three";
import { useInView } from "framer-motion";
import { useRef as useDomRef } from "react";
import { externalSources } from "../../data/content";

function Globe() {
  const ref = useRef<THREE.Group>(null);
  const drag = useRef({ down: false, x: 0, rotY: 0, target: 0 });

  useFrame((_, dt) => {
    if (!ref.current) return;
    if (!drag.current.down) drag.current.target += dt * 0.15;
    drag.current.rotY = THREE.MathUtils.lerp(
      drag.current.rotY,
      drag.current.target,
      0.08
    );
    ref.current.rotation.y = drag.current.rotY;
    ref.current.rotation.x = 0.3;
  });

  return (
    <group
      ref={ref}
      onPointerDown={(e) => {
        drag.current.down = true;
        drag.current.x = e.clientX;
      }}
      onPointerUp={() => {
        drag.current.down = false;
      }}
      onPointerLeave={() => {
        drag.current.down = false;
      }}
      onPointerMove={(e) => {
        if (!drag.current.down) return;
        const dx = e.clientX - drag.current.x;
        drag.current.x = e.clientX;
        drag.current.target += dx * 0.01;
      }}
    >
      <Sphere args={[1.6, 48, 48]}>
        <meshStandardMaterial
          color="#0B3B4A"
          roughness={0.55}
          metalness={0.35}
          emissive="#06252e"
          emissiveIntensity={0.4}
        />
      </Sphere>
      <Sphere args={[1.62, 32, 32]}>
        <meshBasicMaterial color="#00D4AA" wireframe transparent opacity={0.12} />
      </Sphere>
      {externalSources.map((src, i) => {
        const a = (i / externalSources.length) * Math.PI * 2;
        const y = Math.sin(i * 1.7) * 0.6;
        const r = 1.75;
        return (
          <mesh
            key={src}
            position={[Math.cos(a) * r, y, Math.sin(a) * r]}
          >
            <sphereGeometry args={[0.07, 12, 12]} />
            <meshStandardMaterial
              color={i % 2 ? "#0EA5E9" : "#00D4AA"}
              emissive={i % 2 ? "#0EA5E9" : "#00D4AA"}
              emissiveIntensity={1.5}
              toneMapped={false}
            />
          </mesh>
        );
      })}
    </group>
  );
}

export const MiniGlobe = memo(function MiniGlobe() {
  const ref = useDomRef<HTMLDivElement>(null);
  const inView = useInView(ref, { margin: "80px" });

  return (
    <div ref={ref} className="h-[320px] w-full cursor-grab active:cursor-grabbing sm:h-[400px]">
      {inView && (
        <Canvas
          dpr={[1, 1.5]}
          camera={{ position: [0, 0, 5], fov: 40 }}
          gl={{ antialias: true, alpha: true }}
        >
          <ambientLight intensity={0.45} />
          <directionalLight position={[4, 3, 2]} intensity={1.1} />
          <pointLight position={[-3, -2, -2]} color="#0EA5E9" intensity={0.8} />
          <Globe />
        </Canvas>
      )}
    </div>
  );
});
