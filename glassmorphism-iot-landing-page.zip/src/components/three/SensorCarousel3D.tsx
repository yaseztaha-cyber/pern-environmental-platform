import { memo, useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Html, Float } from "@react-three/drei";
import * as THREE from "three";
import { useInView } from "framer-motion";
import { useRef as useDomRef } from "react";
import { physicalSensors, sparklineData } from "../../data/content";
import { Sparkline } from "../ui/Sparkline";
import { useMediaQuery } from "../../hooks/useMediaQuery";

const categoryColor: Record<string, string> = {
  water: "#0EA5E9",
  air: "#00D4AA",
  soil: "#F59E0B",
  light: "#A78BFA",
};

function Carousel({
  active,
  setActive,
  auto,
}: {
  active: number | null;
  setActive: (i: number | null) => void;
  auto: boolean;
}) {
  const group = useRef<THREE.Group>(null);
  const drag = useRef({ active: false, startX: 0, rot: 0, current: 0 });

  useFrame((_, dt) => {
    if (!group.current) return;
    if (!drag.current.active && auto) {
      drag.current.current += dt * 0.18;
    }
    group.current.rotation.y = THREE.MathUtils.lerp(
      group.current.rotation.y,
      drag.current.current,
      0.08
    );
  });

  const radius = 3.2;
  const n = physicalSensors.length;

  return (
    <group
      ref={group}
      onPointerDown={(e) => {
        drag.current.active = true;
        drag.current.startX = e.clientX;
        drag.current.rot = drag.current.current;
        (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
      }}
      onPointerUp={() => {
        drag.current.active = false;
      }}
      onPointerMove={(e) => {
        if (!drag.current.active) return;
        const dx = e.clientX - drag.current.startX;
        drag.current.current = drag.current.rot + dx * 0.005;
      }}
    >
      {physicalSensors.map((sensor, i) => {
        const angle = (i / n) * Math.PI * 2;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        const color = categoryColor[sensor.category];
        const isActive = active === i;
        return (
          <Float
            key={sensor.name}
            speed={1.5}
            floatIntensity={0.2}
            rotationIntensity={0.1}
          >
            <group
              position={[x, isActive ? 0.35 : 0, z]}
              rotation={[0, -angle + Math.PI / 2, 0]}
              scale={isActive ? 1.15 : 1}
              onPointerEnter={() => setActive(i)}
              onPointerLeave={() => setActive(null)}
            >
              <mesh>
                <boxGeometry args={[1.5, 1.05, 0.06]} />
                <meshPhysicalMaterial
                  color="#0f172a"
                  transparent
                  opacity={0.75}
                  roughness={0.2}
                  metalness={0.3}
                  emissive={color}
                  emissiveIntensity={isActive ? 0.25 : 0.08}
                />
              </mesh>
              <Html
                transform
                distanceFactor={1.6}
                position={[0, 0, 0.05]}
                style={{ pointerEvents: "none" }}
              >
                <div
                  style={{
                    width: 170,
                    padding: "10px 12px",
                    borderRadius: 14,
                    border: `1px solid ${color}44`,
                    background: "rgba(2,6,23,0.72)",
                    backdropFilter: "blur(12px)",
                    color: "#F8FAFC",
                    fontFamily: "Inter, sans-serif",
                  }}
                >
                  <div
                    style={{
                      fontSize: 11,
                      color,
                      fontWeight: 600,
                      letterSpacing: "0.04em",
                      textTransform: "uppercase",
                    }}
                  >
                    {sensor.category}
                  </div>
                  <div style={{ fontSize: 14, fontWeight: 700, marginTop: 2 }}>
                    {sensor.name}
                  </div>
                  <div style={{ fontSize: 11, color: "#94A3B8", marginTop: 2 }}>
                    {sensor.unit} · {sensor.range}
                  </div>
                  {isActive && (
                    <div style={{ marginTop: 6, height: 36 }}>
                      <Sparkline
                        data={sparklineData(i + 3)}
                        color={color}
                        height={36}
                      />
                    </div>
                  )}
                </div>
              </Html>
            </group>
          </Float>
        );
      })}
      <mesh>
        <sphereGeometry args={[0.35, 24, 24]} />
        <meshStandardMaterial
          color="#00D4AA"
          emissive="#00D4AA"
          emissiveIntensity={2}
          toneMapped={false}
        />
      </mesh>
      <pointLight color="#00D4AA" intensity={2} distance={5} />
    </group>
  );
}

export const SensorCarousel3D = memo(function SensorCarousel3D() {
  const ref = useDomRef<HTMLDivElement>(null);
  const inView = useInView(ref, { margin: "100px" });
  const [active, setActive] = useState<number | null>(null);
  const isMobile = useMediaQuery("(max-width: 767px)");

  const mobileCards = useMemo(() => physicalSensors, []);

  if (isMobile) {
    return (
      <div className="grid gap-3 sm:grid-cols-2">
        {mobileCards.map((sensor, i) => {
          const color = categoryColor[sensor.category];
          return (
            <div
              key={sensor.name}
              className="glass rounded-3xl p-4"
              style={{ borderColor: `${color}33` }}
            >
              <div className="text-xs font-semibold uppercase tracking-wider" style={{ color }}>
                {sensor.category}
              </div>
              <div className="mt-1 text-base font-semibold">{sensor.name}</div>
              <div className="mt-1 text-xs text-slate-400">
                {sensor.unit} · Safe {sensor.range}
              </div>
              <div className="mt-3 h-10">
                <Sparkline data={sparklineData(i + 3)} color={color} height={40} />
              </div>
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div ref={ref} className="h-[480px] w-full cursor-grab active:cursor-grabbing">
      {inView && (
        <Canvas
          dpr={[1, 1.5]}
          camera={{ position: [0, 2.2, 7.5], fov: 40 }}
          gl={{ antialias: true, alpha: true }}
        >
          <ambientLight intensity={0.4} />
          <pointLight position={[4, 5, 4]} intensity={1} color="#ffffff" />
          <Carousel active={active} setActive={setActive} auto={active === null} />
        </Canvas>
      )}
    </div>
  );
});
