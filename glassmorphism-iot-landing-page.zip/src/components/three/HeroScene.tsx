import { memo, useEffect, useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Sphere } from "@react-three/drei";
import * as THREE from "three";
import { useInView } from "framer-motion";
import { useRef as useDomRef } from "react";
import { sensorNodes } from "../../data/content";
import { useMediaQuery } from "../../hooks/useMediaQuery";

function latLonToVec3(lat: number, lon: number, radius: number) {
  const phi = (90 - lat * 90) * (Math.PI / 180);
  const theta = (lon * 180 + 180) * (Math.PI / 180);
  const x = -(radius * Math.sin(phi) * Math.cos(theta));
  const z = radius * Math.sin(phi) * Math.sin(theta);
  const y = radius * Math.cos(phi);
  return new THREE.Vector3(x, y, z);
}

function WireGlobe() {
  const group = useRef<THREE.Group>(null);
  const mouse = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      mouse.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.current.y = -(e.clientY / window.innerHeight) * 2 + 1;
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  useFrame((_, dt) => {
    if (!group.current) return;
    group.current.rotation.y += dt * 0.08;
    group.current.rotation.x = THREE.MathUtils.lerp(
      group.current.rotation.x,
      mouse.current.y * 0.15,
      0.04
    );
    group.current.rotation.z = THREE.MathUtils.lerp(
      group.current.rotation.z,
      mouse.current.x * 0.08,
      0.04
    );
  });

  const nodes = useMemo(
    () =>
      sensorNodes.map((n) => ({
        ...n,
        pos: latLonToVec3(n.lat * 60 + 20, n.lon * 40 + 30, 1.55),
      })),
    []
  );

  const arcs = useMemo(() => {
    const curves: THREE.Vector3[][] = [];
    for (let i = 0; i < nodes.length; i++) {
      const a = nodes[i].pos;
      const b = nodes[(i + 1) % nodes.length].pos;
      const mid = a.clone().add(b).multiplyScalar(0.5).normalize().multiplyScalar(2.1);
      const curve = new THREE.QuadraticBezierCurve3(a, mid, b);
      curves.push(curve.getPoints(40));
    }
    return curves;
  }, [nodes]);

  return (
    <group ref={group} position={[0, 0.1, 0]} scale={1.15}>
      <Sphere args={[1.4, 32, 32]}>
        <meshBasicMaterial
          color="#00D4AA"
          wireframe
          transparent
          opacity={0.18}
        />
      </Sphere>
      <Sphere args={[1.42, 24, 24]}>
        <meshBasicMaterial
          color="#0EA5E9"
          wireframe
          transparent
          opacity={0.06}
        />
      </Sphere>

      {nodes.map((n) => (
        <Float key={n.name} speed={2} floatIntensity={0.4} rotationIntensity={0.2}>
          <mesh position={n.pos}>
            <icosahedronGeometry args={[0.06, 0]} />
            <meshStandardMaterial
              color="#00D4AA"
              emissive="#00D4AA"
              emissiveIntensity={2}
              toneMapped={false}
            />
          </mesh>
          <pointLight position={n.pos} color="#00D4AA" intensity={0.4} distance={1.5} />
        </Float>
      ))}

      {arcs.map((pts, i) => (
        <line key={i}>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              args={[
                new Float32Array(pts.flatMap((p) => [p.x, p.y, p.z])),
                3,
              ]}
            />
          </bufferGeometry>
          <lineBasicMaterial
            color={i % 2 === 0 ? "#00D4AA" : "#0EA5E9"}
            transparent
            opacity={0.45}
          />
        </line>
      ))}
    </group>
  );
}

function AtmosphereParticles({ count }: { count: number }) {
  const ref = useRef<THREE.Points>(null);
  const { positions, colors, speeds } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const speeds = new Float32Array(count);
    const palette = [
      new THREE.Color("#00D4AA"),
      new THREE.Color("#0EA5E9"),
      new THREE.Color("#F59E0B"),
    ];
    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      const r = 2.5 + Math.random() * 6;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      positions[i3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i3 + 1] = (Math.random() - 0.5) * 8;
      positions[i3 + 2] = r * Math.sin(phi) * Math.sin(theta);
      const c = palette[i % 3];
      colors[i3] = c.r;
      colors[i3 + 1] = c.g;
      colors[i3 + 2] = c.b;
      speeds[i] = 0.15 + Math.random() * 0.35;
    }
    return { positions, colors, speeds };
  }, [count]);

  useFrame((state, dt) => {
    if (!ref.current) return;
    const pos = ref.current.geometry.attributes.position.array as Float32Array;
    const t = state.clock.elapsedTime;
    const mx = state.pointer.x * 0.3;
    const my = state.pointer.y * 0.2;
    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      pos[i3 + 1] += speeds[i] * dt * 0.6;
      pos[i3] += Math.sin(t * 0.4 + i) * 0.002 + mx * 0.002;
      pos[i3 + 2] += Math.cos(t * 0.3 + i) * 0.002 + my * 0.002;
      if (pos[i3 + 1] > 4.5) pos[i3 + 1] = -4.5;
    }
    ref.current.geometry.attributes.position.needsUpdate = true;
    ref.current.rotation.y = t * 0.02;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-color" args={[colors, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.025}
        vertexColors
        transparent
        opacity={0.75}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
}

function SceneContent({ particleCount }: { particleCount: number }) {
  return (
    <>
      <color attach="background" args={["#020617"]} />
      <ambientLight intensity={0.35} />
      <pointLight position={[4, 3, 4]} intensity={1.2} color="#00D4AA" />
      <pointLight position={[-4, -2, -3]} intensity={0.6} color="#0EA5E9" />
      <WireGlobe />
      <AtmosphereParticles count={particleCount} />
      <fog attach="fog" args={["#020617", 6, 16]} />
    </>
  );
}

export const HeroScene = memo(function HeroScene() {
  const containerRef = useDomRef<HTMLDivElement>(null);
  const inView = useInView(containerRef, { margin: "200px" });
  const isMobile = useMediaQuery("(max-width: 767px)");
  const count = isMobile ? 500 : 2000;

  return (
    <div ref={containerRef} className="absolute inset-0 z-0">
      {inView && (
        <Canvas
          dpr={[1, isMobile ? 1.25 : 1.75]}
          camera={{ position: [0, 0, 6.5], fov: 45 }}
          gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
        >
          <SceneContent particleCount={count} />
        </Canvas>
      )}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-[#020617]/20 via-transparent to-[#020617]" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,#020617_75%)]" />
    </div>
  );
});
