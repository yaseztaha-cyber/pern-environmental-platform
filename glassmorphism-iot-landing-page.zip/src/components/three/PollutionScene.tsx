import { memo, useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useInView } from "framer-motion";
import { useRef as useDomRef } from "react";

function ContaminatedCube({ progress }: { progress: number }) {
  const clean = useRef<THREE.Mesh>(null);
  const dirty = useRef<THREE.Mesh>(null);
  const particles = useRef<THREE.Points>(null);

  const particlePos = useMemo(() => {
    const arr = new Float32Array(400 * 3);
    for (let i = 0; i < 400; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 2.2;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 2.2;
      arr[i * 3 + 2] = (Math.random() - 0.5) * 2.2;
    }
    return arr;
  }, []);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (clean.current) {
      clean.current.rotation.y = t * 0.2;
      clean.current.rotation.x = Math.sin(t * 0.15) * 0.15;
      const mat = clean.current.material as THREE.MeshPhysicalMaterial;
      mat.opacity = 0.55 * (1 - progress * 0.7);
    }
    if (dirty.current) {
      dirty.current.rotation.y = t * 0.25 + 0.4;
      dirty.current.rotation.x = Math.cos(t * 0.12) * 0.2;
      const mat = dirty.current.material as THREE.MeshPhysicalMaterial;
      mat.opacity = 0.15 + progress * 0.55;
      mat.color.lerpColors(
        new THREE.Color("#10B981"),
        new THREE.Color("#7f1d1d"),
        progress
      );
    }
    if (particles.current) {
      particles.current.rotation.y = t * 0.1;
      const mat = particles.current.material as THREE.PointsMaterial;
      mat.opacity = 0.15 + progress * 0.7;
      particles.current.scale.setScalar(0.8 + progress * 0.5);
    }
  });

  return (
    <group>
      <mesh ref={clean} position={[-1.3, 0, 0]}>
        <boxGeometry args={[1.6, 1.6, 1.6]} />
        <meshPhysicalMaterial
          color="#5eead4"
          transparent
          opacity={0.45}
          roughness={0.1}
          metalness={0.1}
          transmission={0.6}
          thickness={0.5}
        />
      </mesh>
      <mesh ref={dirty} position={[1.3, 0, 0]}>
        <boxGeometry args={[1.6, 1.6, 1.6]} />
        <meshPhysicalMaterial
          color="#7f1d1d"
          transparent
          opacity={0.5}
          roughness={0.4}
          metalness={0.2}
        />
      </mesh>
      <points ref={particles} position={[1.3, 0, 0]}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[particlePos, 3]} />
        </bufferGeometry>
        <pointsMaterial
          color="#EF4444"
          size={0.04}
          transparent
          opacity={0.5}
          depthWrite={false}
        />
      </points>
    </group>
  );
}

export const PollutionScene = memo(function PollutionScene({
  progress,
}: {
  progress: number;
}) {
  const ref = useDomRef<HTMLDivElement>(null);
  const inView = useInView(ref, { margin: "100px" });

  return (
    <div ref={ref} className="h-full min-h-[280px] w-full">
      {inView && (
        <Canvas
          dpr={[1, 1.5]}
          camera={{ position: [0, 0.5, 6], fov: 40 }}
          gl={{ antialias: true, alpha: true }}
        >
          <ambientLight intensity={0.5} />
          <pointLight position={[3, 4, 5]} intensity={1.2} color="#00D4AA" />
          <pointLight position={[-3, -2, 2]} intensity={0.8} color="#EF4444" />
          <ContaminatedCube progress={progress} />
        </Canvas>
      )}
    </div>
  );
});
