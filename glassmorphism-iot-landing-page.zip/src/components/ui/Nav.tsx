import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Activity, Menu, X } from "lucide-react";
import { cn } from "../../utils/cn";
import { Button } from "./Button";

const links = [
  { href: "#problem", label: "Problem" },
  { href: "#architecture", label: "Architecture" },
  { href: "#sensors", label: "Sensors" },
  { href: "#ai", label: "AI" },
  { href: "#eri", label: "ERI" },
  { href: "#team", label: "Team" },
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.2, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-x-0 top-0 z-50 px-4 pt-4 sm:px-6"
    >
      <div
        className={cn(
          "mx-auto flex max-w-7xl items-center justify-between rounded-full px-4 py-2.5 transition-all duration-500 sm:px-6",
          scrolled ? "glass-strong shadow-[0_10px_40px_-20px_rgba(0,0,0,0.8)]" : "bg-transparent"
        )}
      >
        <a href="#hero" className="flex items-center gap-2.5" data-cursor="hover">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#00D4AA]/15 text-[#00D4AA] ring-1 ring-[#00D4AA]/30">
            <Activity className="h-4 w-4" />
          </span>
          <span className="text-sm font-semibold tracking-tight sm:text-base">
            PERN
          </span>
        </a>

        <nav className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              data-cursor="hover"
              className="rounded-full px-3 py-1.5 text-sm text-slate-400 transition hover:bg-white/5 hover:text-white"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-2 sm:flex">
          <Button
            variant="secondary"
            size="md"
            onClick={() =>
              document.getElementById("cta")?.scrollIntoView({ behavior: "smooth" })
            }
          >
            Request Pilot
          </Button>
        </div>

        <button
          className="glass flex h-10 w-10 items-center justify-center rounded-full lg:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
          data-cursor="hover"
        >
          {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </button>
      </div>

      {open && (
        <div className="glass-strong mx-auto mt-2 max-w-7xl rounded-3xl p-4 lg:hidden">
          <div className="flex flex-col gap-1">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="rounded-2xl px-4 py-3 text-sm text-slate-300 hover:bg-white/5 hover:text-white"
              >
                {l.label}
              </a>
            ))}
            <Button
              className="mt-2 w-full"
              onClick={() => {
                setOpen(false);
                document.getElementById("cta")?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              Request Pilot
            </Button>
          </div>
        </div>
      )}
    </motion.header>
  );
}
