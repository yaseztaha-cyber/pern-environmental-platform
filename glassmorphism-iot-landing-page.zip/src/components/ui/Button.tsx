import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from "react";
import { cn } from "../../utils/cn";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost";
  size?: "md" | "lg" | "xl";
  children: ReactNode;
  asChild?: boolean;
};

export const Button = forwardRef<HTMLButtonElement, Props>(
  (
    { className, variant = "primary", size = "md", children, ...rest },
    ref
  ) => {
    return (
      <button
        ref={ref}
        data-cursor="hover"
        className={cn(
          "inline-flex items-center justify-center gap-2 rounded-full font-semibold tracking-tight transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-400/60",
          size === "md" && "px-5 py-2.5 text-sm",
          size === "lg" && "px-7 py-3.5 text-base",
          size === "xl" && "px-10 py-5 text-lg sm:text-xl",
          variant === "primary" &&
            "bg-[#00D4AA] text-slate-950 shadow-[0_0_40px_-10px_rgba(0,212,170,0.55)] hover:scale-105 hover:bg-[#2ee6bf] hover:shadow-[0_0_50px_-8px_rgba(0,212,170,0.75)]",
          variant === "secondary" &&
            "glass text-slate-100 hover:scale-105 hover:border-teal-400/30 hover:bg-white/5",
          variant === "ghost" &&
            "text-slate-300 hover:text-white hover:underline underline-offset-4",
          className
        )}
        {...rest}
      >
        {children}
      </button>
    );
  }
);

Button.displayName = "Button";
