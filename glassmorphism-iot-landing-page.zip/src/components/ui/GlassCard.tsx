import { forwardRef, type HTMLAttributes, type ReactNode } from "react";
import { cn } from "../../utils/cn";

type Props = HTMLAttributes<HTMLDivElement> & {
  children: ReactNode;
  glow?: boolean;
  strong?: boolean;
};

export const GlassCard = forwardRef<HTMLDivElement, Props>(
  ({ children, className, glow, strong, ...rest }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          strong ? "glass-strong" : "glass",
          glow && "glass-glow",
          "rounded-3xl",
          className
        )}
        {...rest}
      >
        {children}
      </div>
    );
  }
);

GlassCard.displayName = "GlassCard";
