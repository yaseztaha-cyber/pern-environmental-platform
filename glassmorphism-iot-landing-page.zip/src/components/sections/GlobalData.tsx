import { Globe2, Shield } from "lucide-react";
import { MiniGlobe } from "../three/MiniGlobe";
import { complianceFrameworks, externalSources } from "../../data/content";
import { GlassCard } from "../ui/GlassCard";
import { Pill } from "../ui/Pill";
import { SectionReveal } from "../ui/SectionReveal";

export function GlobalData() {
  return (
    <section id="global" className="section-pad relative overflow-hidden">
      <div className="mx-auto max-w-7xl">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <SectionReveal>
            <Pill className="mb-4">
              <Globe2 className="h-3.5 w-3.5 text-[#0EA5E9]" />
              Beyond Your Sensors
            </Pill>
            <h2 className="heading-lg mb-5 text-white">Global Data Fabric</h2>
            <p className="mb-8 text-slate-400">
              PERN fuses local IoT streams with planetary open data — satellite
              fire detections, community air networks, and atmospheric composition
              models — so your risk score is never blind outside the node radius.
            </p>

            <div className="mb-8 grid gap-3 sm:grid-cols-2">
              {externalSources.map((src) => (
                <GlassCard key={src} className="px-4 py-3 text-sm font-medium text-slate-200">
                  <span className="mr-2 inline-block h-1.5 w-1.5 rounded-full bg-[#00D4AA]" />
                  {src}
                </GlassCard>
              ))}
            </div>

            <div className="flex items-center gap-2 text-sm font-semibold text-white">
              <Shield className="h-4 w-4 text-[#00D4AA]" />
              Compliance Frameworks
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {complianceFrameworks.map((f) => (
                <span
                  key={f}
                  className="glass rounded-full px-3 py-1.5 text-xs text-slate-300"
                >
                  {f}
                </span>
              ))}
            </div>
          </SectionReveal>

          <SectionReveal delay={0.1}>
            <GlassCard glow className="overflow-hidden p-2">
              <MiniGlobe />
            </GlassCard>
          </SectionReveal>
        </div>
      </div>
    </section>
  );
}
