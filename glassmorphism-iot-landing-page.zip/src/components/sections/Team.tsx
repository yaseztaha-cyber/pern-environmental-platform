import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { GraduationCap, User } from "lucide-react";
import { team } from "../../data/content";
import { GlassCard } from "../ui/GlassCard";
import { Pill } from "../ui/Pill";
import { SectionReveal } from "../ui/SectionReveal";
import { useMediaQuery } from "../../hooks/useMediaQuery";
import { cn } from "../../utils/cn";

gsap.registerPlugin(ScrollTrigger);

export function Team() {
  const trackRef = useRef<HTMLDivElement>(null);
  const sectionRef = useRef<HTMLElement>(null);
  const isMobile = useMediaQuery("(max-width: 767px)");

  useEffect(() => {
    if (isMobile) return;
    const section = sectionRef.current;
    const track = trackRef.current;
    if (!section || !track) return;

    const cards = track.querySelectorAll(".team-card");
    const ctx = gsap.context(() => {
      const total = track.scrollWidth - window.innerWidth + 80;
      gsap.to(track, {
        x: () => -Math.max(0, total),
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top top",
          end: () => `+=${Math.max(total, 400)}`,
          pin: true,
          scrub: 1,
          invalidateOnRefresh: true,
          onUpdate: (self) => {
            cards.forEach((card, i) => {
              const p = self.progress;
              const offset = (i / cards.length - p) * 40;
              gsap.set(card, { rotateY: offset });
            });
          },
        },
      });
    }, section);

    return () => ctx.revert();
  }, [isMobile]);

  const people = [
    { name: team.supervisor, role: "Supervisor" },
    ...team.members.map((m) => ({ name: m, role: "25% contribution" })),
  ];

  return (
    <section id="team" ref={sectionRef} className="relative overflow-hidden">
      <div className={cn("section-pad", !isMobile && "min-h-screen")}>
        <SectionReveal className="mx-auto mb-10 max-w-7xl">
          <Pill className="mb-4">
            <GraduationCap className="h-3.5 w-3.5 text-[#00D4AA]" />
            STEM Gharbiya · Grade 11 · 2026
          </Pill>
          <h2 className="heading-lg text-white">The Team</h2>
        </SectionReveal>

        <div
          ref={trackRef}
          className={cn(
            "flex gap-5 px-5 sm:px-10",
            isMobile ? "flex-col" : "w-max"
          )}
        >
          {people.map((p) => (
            <GlassCard
              key={p.name}
              glow
              className={cn(
                "team-card preserve-3d flex flex-col items-start p-6",
                isMobile ? "w-full" : "h-[280px] w-[300px] shrink-0"
              )}
            >
              <span className="mb-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-400/20 to-sky-500/10 text-[#00D4AA] ring-1 ring-white/10">
                <User className="h-6 w-6" />
              </span>
              <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-[#00D4AA]">
                {p.role}
              </div>
              <h3 className="text-lg font-semibold leading-snug text-white">
                {p.name}
              </h3>
            </GlassCard>
          ))}
        </div>

        <p className="mx-auto mt-12 max-w-7xl px-5 text-center text-xs text-slate-500 sm:px-10 sm:text-sm">
          Created & Owned by {team.owner} · STEM Gharbiya · All Rights Reserved ©
          2026
        </p>
      </div>
    </section>
  );
}
