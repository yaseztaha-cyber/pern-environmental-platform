import { Layers, Cpu } from "lucide-react";
import { SensorCarousel3D } from "../three/SensorCarousel3D";
import { virtualSensors } from "../../data/content";
import { GlassCard } from "../ui/GlassCard";
import { Pill } from "../ui/Pill";
import { SectionReveal } from "../ui/SectionReveal";
import { cn } from "../../utils/cn";

function Gauge({ value, color }: { value: number; color: string }) {
  const r = 28;
  const c = 2 * Math.PI * r;
  const offset = c - (value / 100) * c;
  return (
    <svg width="72" height="72" viewBox="0 0 72 72" className="shrink-0">
      <circle
        cx="36"
        cy="36"
        r={r}
        fill="none"
        stroke="rgba(255,255,255,0.06)"
        strokeWidth="6"
      />
      <circle
        cx="36"
        cy="36"
        r={r}
        fill="none"
        stroke={color}
        strokeWidth="6"
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={offset}
        className="gauge-ring"
        transform="rotate(-90 36 36)"
        style={{ filter: `drop-shadow(0 0 6px ${color}88)` }}
      />
      <text
        x="36"
        y="40"
        textAnchor="middle"
        fill="#F8FAFC"
        fontSize="12"
        fontWeight="600"
        fontFamily="Inter, sans-serif"
      >
        {value}
      </text>
    </svg>
  );
}

const tierColor = (tier: number) => {
  if (tier === 1) return "#00D4AA";
  if (tier === 2) return "#0EA5E9";
  if (tier === 3) return "#F59E0B";
  return "#A78BFA";
};

export function Sensors() {
  return (
    <section id="sensors" className="section-pad relative overflow-hidden">
      <div className="mx-auto max-w-7xl">
        <SectionReveal>
          <Pill className="mb-4">
            <Cpu className="h-3.5 w-3.5 text-[#00D4AA]" />
            Sensor Universe
          </Pill>
          <h2 className="heading-lg mb-3 text-white">14 Physical. 10 Virtual.</h2>
          <p className="mb-10 max-w-2xl text-slate-400">
            Drag the cylindrical carousel to explore every physical sensor. Hover
            a node for live sparklines. Virtual indices fuse raw telemetry into
            decision-ready intelligence.
          </p>
        </SectionReveal>

        <SectionReveal delay={0.1}>
          <SensorCarousel3D />
        </SectionReveal>

        <SectionReveal delay={0.15} className="mt-16">
          <div className="mb-6 flex items-center gap-2">
            <Layers className="h-4 w-4 text-[#0EA5E9]" />
            <h3 className="text-lg font-semibold text-white">Virtual Sensors</h3>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {virtualSensors.map((vs) => {
              const color = tierColor(vs.tier);
              return (
                <GlassCard
                  key={vs.name}
                  className="flex items-center gap-3 p-4 transition hover:border-white/15"
                >
                  <Gauge value={vs.value} color={color} />
                  <div>
                    <div className="text-sm font-semibold text-white">{vs.name}</div>
                    <span
                      className={cn(
                        "mt-1 inline-flex rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider"
                      )}
                      style={{
                        background: `${color}22`,
                        color,
                      }}
                    >
                      Tier {vs.tier}
                    </span>
                  </div>
                </GlassCard>
              );
            })}
          </div>
        </SectionReveal>
      </div>
    </section>
  );
}
