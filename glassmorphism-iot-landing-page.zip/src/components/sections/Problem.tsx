import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { AlertTriangle } from "lucide-react";
import { PollutionScene } from "../three/PollutionScene";
import { problemLabels } from "../../data/content";
import { Pill } from "../ui/Pill";
import { GlassCard } from "../ui/GlassCard";
import { SectionReveal } from "../ui/SectionReveal";

gsap.registerPlugin(ScrollTrigger);

export function Problem() {
  const sectionRef = useRef<HTMLElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: el,
        start: "top top",
        end: "+=120%",
        pin: true,
        scrub: 0.6,
        onUpdate: (self) => setProgress(self.progress),
      });
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="problem"
      ref={sectionRef}
      className="relative flex min-h-screen items-center overflow-hidden"
    >
      <div className="section-pad mx-auto grid w-full max-w-7xl items-center gap-10 lg:grid-cols-2">
        <SectionReveal>
          <Pill className="mb-6">
            <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />
            Invisible Threats
          </Pill>
          <h2 className="heading-lg mb-6 text-white">
            Environmental data is either too expensive, too complex, or too late.
          </h2>
          <p className="mb-8 max-w-xl text-base leading-relaxed text-slate-400 sm:text-lg">
            Commercial stations cost $800–$3,000 per unit. They report what
            already happened. PERN changes the paradigm: low-cost ESP32 nodes,
            predictive ML, and an Environmental Risk Index anyone can understand.
          </p>

          <div className="mb-6">
            <div className="mb-2 flex items-center justify-between text-xs uppercase tracking-wider text-slate-500">
              <span>Clean</span>
              <span>Contaminated</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-white/5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-emerald-400 via-amber-400 to-red-500 transition-[width] duration-150"
                style={{ width: `${Math.max(8, progress * 100)}%` }}
              />
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            {problemLabels.map((label, i) => (
              <GlassCard
                key={label}
                className="p-4 text-sm text-slate-300 transition-opacity"
                style={{ opacity: 0.35 + Math.min(1, progress * 2 + i * 0.1) * 0.65 }}
              >
                {label}
              </GlassCard>
            ))}
          </div>
        </SectionReveal>

        <div className="relative h-[360px] sm:h-[440px]">
          <div className="absolute inset-0 rounded-[1.5rem] bg-gradient-to-b from-teal-500/5 to-transparent" />
          <PollutionScene progress={progress} />
          <div className="pointer-events-none absolute left-4 top-4">
            <span className="glass rounded-full px-3 py-1 text-xs text-emerald-300">
              Pristine
            </span>
          </div>
          <div className="pointer-events-none absolute right-4 top-4">
            <span className="glass rounded-full px-3 py-1 text-xs text-red-300">
              PM2.5 + Gas
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
