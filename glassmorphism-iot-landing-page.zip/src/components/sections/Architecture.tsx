import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import {
  Cpu,
  Network,
  Server,
  Database,
  LayoutDashboard,
  Radio,
} from "lucide-react";
import { architectureLayers } from "../../data/content";
import { GlassCard } from "../ui/GlassCard";
import { Pill } from "../ui/Pill";
import { useMediaQuery } from "../../hooks/useMediaQuery";
import { cn } from "../../utils/cn";

gsap.registerPlugin(ScrollTrigger);

const icons = [Cpu, Network, Server, Database, LayoutDashboard];

export function Architecture() {
  const sectionRef = useRef<HTMLElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const isMobile = useMediaQuery("(max-width: 767px)");

  useEffect(() => {
    if (isMobile) return;
    const section = sectionRef.current;
    const track = trackRef.current;
    if (!section || !track) return;

    const ctx = gsap.context(() => {
      const totalScroll = track.scrollWidth - window.innerWidth;
      gsap.to(track, {
        x: () => -totalScroll,
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top top",
          end: () => `+=${totalScroll}`,
          pin: true,
          scrub: 1,
          invalidateOnRefresh: true,
        },
      });
    }, section);

    return () => ctx.revert();
  }, [isMobile]);

  return (
    <section
      id="architecture"
      ref={sectionRef}
      className="relative overflow-hidden"
    >
      <div className={cn(!isMobile && "h-screen")}>
        <div className="section-pad pb-6 pt-24">
          <div className="mx-auto max-w-7xl">
            <Pill className="mb-4">
              <Radio className="h-3.5 w-3.5 text-[#00D4AA]" />
              System Design
            </Pill>
            <h2 className="heading-lg text-white">Five Layers of Intelligence</h2>
            <p className="mt-3 max-w-2xl text-slate-400">
              From field devices to predictive dashboards — a unified stack for
              environmental intelligence across the Nile Delta.
            </p>
          </div>
        </div>

        <div
          ref={trackRef}
          className={cn(
            "flex gap-6 px-5 pb-16 sm:px-10",
            isMobile && "flex-col"
          )}
          style={!isMobile ? { width: "max-content" } : undefined}
        >
          {architectureLayers.map((layer, i) => {
            const Icon = icons[i];
            return (
              <GlassCard
                key={layer.id}
                glow
                className={cn(
                  "relative flex flex-col overflow-hidden p-8",
                  isMobile ? "w-full" : "h-[min(60vh,520px)] w-[min(85vw,420px)] shrink-0"
                )}
              >
                <div
                  className="absolute -right-10 -top-10 h-40 w-40 rounded-full opacity-30 blur-3xl"
                  style={{ background: layer.accent }}
                />
                <div className="mb-6 flex items-center justify-between">
                  <span
                    className="flex h-12 w-12 items-center justify-center rounded-2xl"
                    style={{
                      background: `${layer.accent}22`,
                      color: layer.accent,
                      boxShadow: `0 0 30px -8px ${layer.accent}`,
                    }}
                  >
                    <Icon className="h-5 w-5" />
                  </span>
                  <span className="text-xs font-medium uppercase tracking-widest text-slate-500">
                    Layer 0{i + 1}
                  </span>
                </div>
                <h3 className="heading-md mb-3 text-white">{layer.title}</h3>
                <p className="mb-6 flex-1 text-sm leading-relaxed text-slate-400">
                  {layer.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {layer.items.map((item) => (
                    <span
                      key={item}
                      className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300"
                    >
                      {item}
                    </span>
                  ))}
                </div>

                {!isMobile && i < architectureLayers.length - 1 && (
                  <div className="pointer-events-none absolute -right-3 top-1/2 hidden h-px w-6 bg-gradient-to-r from-teal-400/60 to-transparent lg:block" />
                )}
              </GlassCard>
            );
          })}
        </div>
      </div>
    </section>
  );
}
