import { motion } from "framer-motion";
import { Award, Factory, Sprout } from "lucide-react";
import { deployments } from "../../data/content";
import { GlassCard } from "../ui/GlassCard";
import { Pill } from "../ui/Pill";
import { SectionReveal } from "../ui/SectionReveal";

export function Proof() {
  const icons = [Factory, Sprout];

  return (
    <section id="proof" className="section-pad relative overflow-hidden">
      <div className="mx-auto max-w-7xl">
        <SectionReveal className="mb-12 text-center">
          <Pill className="mb-4">Deployed. Validated.</Pill>
          <h2 className="heading-lg text-white">Proof of Work</h2>
        </SectionReveal>

        <div className="relative grid gap-6 lg:grid-cols-2">
          {deployments.map((d, i) => {
            const Icon = icons[i];
            return (
              <SectionReveal key={d.title} delay={i * 0.1}>
                <motion.div
                  whileHover={{ rotateY: i === 0 ? 4 : -4, scale: 1.02 }}
                  transition={{ type: "spring", stiffness: 200, damping: 20 }}
                  className="perspective-1000 h-full"
                >
                  <GlassCard glow className="h-full p-6 sm:p-8">
                    <div className="mb-5 flex items-center gap-3">
                      <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#00D4AA]/15 text-[#00D4AA]">
                        <Icon className="h-5 w-5" />
                      </span>
                      <div>
                        <h3 className="text-lg font-semibold text-white">
                          {d.title}
                        </h3>
                        <p className="text-sm text-slate-400">{d.location}</p>
                      </div>
                    </div>
                    <ul className="space-y-3">
                      {d.stats.map((s) => (
                        <li
                          key={s}
                          className="border-l-2 border-[#00D4AA]/40 pl-3 text-sm text-slate-300"
                        >
                          {s}
                        </li>
                      ))}
                    </ul>
                  </GlassCard>
                </motion.div>
              </SectionReveal>
            );
          })}

          <div className="pointer-events-none absolute left-1/2 top-1/2 z-10 hidden -translate-x-1/2 -translate-y-1/2 lg:block">
            <div className="glass-strong glass-glow rounded-full px-5 py-3 text-center text-xs font-medium text-teal-100 shadow-2xl">
              <Award className="mx-auto mb-1 h-4 w-4 text-[#00D4AA]" />
              Random Forest Regression
              <br />
              R² = 0.94 · MAE below preset limits
            </div>
          </div>
        </div>

        <div className="mt-6 text-center lg:hidden">
          <GlassCard glow className="inline-block px-5 py-3 text-xs text-teal-100">
            Random Forest Regression · R² = 0.94 · MAE below preset limits
          </GlassCard>
        </div>
      </div>
    </section>
  );
}
