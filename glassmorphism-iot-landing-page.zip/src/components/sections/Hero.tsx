import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { motion } from "framer-motion";
import { ArrowRight, Map, Sparkles } from "lucide-react";
import { HeroScene } from "../three/HeroScene";
import { Button } from "../ui/Button";
import { Pill } from "../ui/Pill";
import { liveStats } from "../../data/content";
import { useCountUp } from "../../hooks/useCountUp";

function StatItem({
  label,
  value,
  enabled,
}: {
  label: string;
  value: number;
  enabled: boolean;
}) {
  const n = useCountUp(value, enabled);
  return (
    <div className="flex min-w-[110px] flex-col items-center px-3 py-1 sm:min-w-[130px]">
      <span className="text-lg font-semibold tabular-nums text-white sm:text-2xl">
        {n}
      </span>
      <span className="text-[10px] uppercase tracking-wider text-slate-400 sm:text-xs">
        {label}
      </span>
    </div>
  );
}

export function Hero() {
  const root = useRef<HTMLElement>(null);
  const [statsOn, setStatsOn] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: "power3.out" } });
      tl.fromTo(
        root.current,
        { opacity: 0 },
        { opacity: 1, duration: 0.4 }
      )
        .fromTo(
          ".hero-line",
          { y: 80, opacity: 0, clipPath: "inset(0 0 100% 0)" },
          {
            y: 0,
            opacity: 1,
            clipPath: "inset(0 0 0% 0)",
            duration: 0.9,
            stagger: 0.12,
          },
          0.35
        )
        .fromTo(
          ".hero-sub",
          { y: 24, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7 },
          0.85
        )
        .fromTo(
          ".hero-cta",
          { y: 20, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6 },
          1.1
        )
        .fromTo(
          ".hero-stats",
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7 },
          1.0
        );

      gsap.delayedCall(1.0, () => setStatsOn(true));
    }, root);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="hero"
      ref={root}
      className="relative flex min-h-screen items-center justify-center overflow-hidden pt-24 pb-32"
    >
      <HeroScene />

      <div className="relative z-10 mx-auto flex max-w-5xl flex-col items-center px-5 text-center">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.6 }}
        >
          <Pill className="mb-8">
            <Sparkles className="h-3.5 w-3.5 text-[#00D4AA]" />
            AI-Powered Environmental Intelligence
          </Pill>
        </motion.div>

        <h1 className="heading-xl mb-6">
          <span className="hero-line block text-gradient">Predictive</span>
          <span className="hero-line block text-gradient">Environmental</span>
          <span className="hero-line block text-gradient">Risk Network</span>
        </h1>

        <p className="hero-sub mx-auto mb-10 max-w-2xl text-base leading-relaxed text-slate-400 sm:text-lg">
          Real-time monitoring, 24-hour pollution forecasting, and unified risk
          scoring for air, water, and soil. Built for the Nile Delta. Deployable
          anywhere.
        </p>

        <div className="hero-cta flex flex-col items-center gap-3 sm:flex-row sm:gap-4">
          <Button
            size="lg"
            onClick={() =>
              document.getElementById("dashboard")?.scrollIntoView({ behavior: "smooth" })
            }
          >
            Explore the Dashboard
            <ArrowRight className="h-4 w-4" />
          </Button>
          <Button
            variant="secondary"
            size="lg"
            onClick={() =>
              document.getElementById("sensors")?.scrollIntoView({ behavior: "smooth" })
            }
          >
            <Map className="h-4 w-4" />
            View Live Sensor Map
          </Button>
        </div>
      </div>

      <div className="hero-stats absolute bottom-8 left-1/2 z-10 w-[min(960px,92vw)] -translate-x-1/2">
        <div className="glass glass-glow flex flex-wrap items-center justify-center gap-1 rounded-full px-2 py-3 sm:gap-0 sm:px-4">
          {liveStats.map((s, i) => (
            <div key={s.label} className="flex items-center">
              <StatItem label={s.label} value={s.value} enabled={statsOn} />
              {i < liveStats.length - 1 && (
                <div className="hidden h-8 w-px bg-white/10 sm:block" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
