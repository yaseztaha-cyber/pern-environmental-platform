import { FileText, Mail, Building2, Code2 } from "lucide-react";
import { ParticleField } from "../three/ParticleField";
import { Button } from "../ui/Button";
import { SectionReveal } from "../ui/SectionReveal";

const links = [
  { label: "Documentation", icon: FileText, href: "#" },
  { label: "GitHub", icon: Code2, href: "#" },
  { label: "Contact", icon: Mail, href: "#" },
  { label: "Ministry Inquiry", icon: Building2, href: "#" },
];

export function CTAFooter() {
  return (
    <section
      id="cta"
      className="relative flex min-h-[90vh] items-center overflow-hidden py-24"
    >
      <ParticleField denser />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-[#020617] via-transparent to-[#020617]" />

      <div className="relative z-10 mx-auto w-full max-w-5xl px-5 text-center">
        <SectionReveal>
          <h2 className="heading-lg mb-10 text-balance text-white">
            The future of environmental monitoring is{" "}
            <span className="text-gradient">predictive</span>, distributed, and
            affordable.
          </h2>

          <Button size="xl" className="animate-pulse-glow mb-10">
            Request a Pilot Deployment
          </Button>

          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-5">
            {links.map((l) => (
              <a
                key={l.label}
                href={l.href}
                data-cursor="hover"
                className="glass inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm text-slate-300 transition hover:border-teal-400/30 hover:text-white"
              >
                <l.icon className="h-4 w-4 text-[#00D4AA]" />
                {l.label}
              </a>
            ))}
          </div>

          <div className="mt-16 border-t border-white/5 pt-8 text-xs text-slate-600">
            PERN — Predictive Environmental Risk Network · Pollution &
            Environmental Risk Navigator · Nile Delta · © 2026
          </div>
        </SectionReveal>
      </div>
    </section>
  );
}
