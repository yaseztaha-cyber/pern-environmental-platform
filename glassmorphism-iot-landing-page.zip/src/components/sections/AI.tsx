import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Bot, Check, Sparkles } from "lucide-react";
import { aiFeatures, chatDemo } from "../../data/content";
import { GlassCard } from "../ui/GlassCard";
import { Pill } from "../ui/Pill";
import { SectionReveal } from "../ui/SectionReveal";

export function AI() {
  const [visibleCount, setVisibleCount] = useState(1);

  useEffect(() => {
    const id = window.setInterval(() => {
      setVisibleCount((c) => (c >= chatDemo.length ? 1 : c + 1));
    }, 2800);
    return () => window.clearInterval(id);
  }, []);

  return (
    <section id="ai" className="section-pad relative overflow-hidden">
      <div className="mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-2">
        <SectionReveal>
          <Pill className="mb-4">
            <Sparkles className="h-3.5 w-3.5 text-[#00D4AA]" />
            Think in Natural Language
          </Pill>
          <h2 className="heading-lg mb-5 text-white">
            An AI Copilot for Environmental Data
          </h2>
          <ul className="mb-8 space-y-4">
            {aiFeatures.map((f, i) => (
              <motion.li
                key={f.title}
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="flex gap-3"
              >
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#00D4AA]/15 text-[#00D4AA]">
                  <Check className="h-3.5 w-3.5" />
                </span>
                <div>
                  <div className="font-semibold text-white">{f.title}</div>
                  <div className="text-sm text-slate-400">{f.description}</div>
                </div>
              </motion.li>
            ))}
          </ul>
          <Pill className="glass-glow text-[11px] sm:text-xs">
            Powered by OpenRouter • 1M-token context • nvidia/nemotron-3-super-120b
          </Pill>
        </SectionReveal>

        <SectionReveal delay={0.1}>
          <div className="perspective-1000 relative mx-auto max-w-md lg:max-w-none">
            <div
              className="preserve-3d relative"
              style={{
                transform: "rotateY(-8deg) rotateX(5deg)",
              }}
            >
              <GlassCard strong glow className="relative overflow-hidden p-5 sm:p-6">
                <div className="mb-5 flex items-center gap-3 border-b border-white/10 pb-4">
                  <span className="relative flex h-10 w-10 items-center justify-center rounded-full bg-[#00D4AA]/20">
                    <Bot className="h-5 w-5 text-[#00D4AA]" />
                    <span className="absolute inset-0 animate-ping rounded-full bg-[#00D4AA]/20" />
                  </span>
                  <div>
                    <div className="text-sm font-semibold">PERN Copilot</div>
                    <div className="text-xs text-emerald-400">Streaming · Online</div>
                  </div>
                  <div className="ml-auto h-px w-16 bg-gradient-to-r from-transparent via-teal-400/60 to-transparent" />
                </div>

                <div className="flex min-h-[320px] flex-col gap-3">
                  <AnimatePresence mode="popLayout">
                    {chatDemo.slice(0, visibleCount).map((msg, i) => (
                      <motion.div
                        key={`${msg.role}-${i}-${visibleCount > i}`}
                        initial={{ opacity: 0, y: 16, z: 40 }}
                        animate={{
                          opacity: 1,
                          y: 0,
                          z: (visibleCount - i) * -12,
                          scale: 1 - (visibleCount - 1 - i) * 0.02,
                        }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ type: "spring", stiffness: 260, damping: 24 }}
                        className={
                          msg.role === "user"
                            ? "ml-8 rounded-2xl rounded-br-md bg-[#00D4AA]/15 px-4 py-3 text-sm text-teal-50"
                            : "mr-6 rounded-2xl rounded-bl-md border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-200"
                        }
                      >
                        {msg.text}
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </GlassCard>
            </div>
            <div className="pointer-events-none absolute -right-4 -top-4 h-24 w-24 rounded-full bg-teal-400/20 blur-3xl" />
          </div>
        </SectionReveal>
      </div>
    </section>
  );
}
